#include <SFML/Graphics.hpp>

using namespace std;

int main()
{
    return 0;
}